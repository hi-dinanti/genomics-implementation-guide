# Home - FHIR Implementation Guide Genomics Reporting (Draft) v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.gsilab.id/ImplementationGuide/hl7.fhir.r4.id.gsilab | *Version*:0.1.0 |
| Draft as of 2026-02-05 | *Computable Name*:gsilab |

